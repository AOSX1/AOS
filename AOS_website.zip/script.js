function alertMessage() {
    alert("AOS – Minimal • Modern • Digital");
}
